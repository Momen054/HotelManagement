﻿namespace HotelManagement.Models
{
    public class Review
    {
        public int Id { get; set; }

        public int GuestId { get; set; }

        public Guest? Guest { get; set; }

        public int ReservationId { get; set; }

        public Reservation? Reservation { get; set; }

        public int Rating { get; set; }

        public string? Comment { get; set; }

    }
}
