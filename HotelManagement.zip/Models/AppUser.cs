﻿using Microsoft.AspNetCore.Identity;

namespace HotelManagement.Models
{
    public class AppUser : IdentityUser
    {

        public string FullName { get; set; } = string.Empty;    
        
        public Guest? Guest { get; set; }

        public Employee? Employee { get; set; }

        public ICollection<RefreshToken> RefreshTokens { get; set; } = new List<RefreshToken>();

    }
}
