﻿using HotelManagement.DTOs.Reservation;

namespace HotelManagement.serviceInterfaces
{
    public interface IReservation
    {
        Task<IEnumerable<GetReservation>> GetReservation();

        Task<GetReservation> GetReservation(int id);

        Task PutReservation(PutReservation reservation);

        Task PostReservation(PostReservation reservation);

        Task DeleteReservation(int id);
    }
}
