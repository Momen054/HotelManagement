﻿using HotelManagement.Data;
using HotelManagement.DTOs.Payment;
using HotelManagement.Models;
using HotelManagement.serviceInterfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPayment _payment;
        public PaymentController(IPayment payment)
        {
            _payment = payment;
        }

        // GET: api/Payment
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetPayment>>> GetPayment()
            => Ok(await _payment.GetPayment());


        // GET: api/Payment/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GetPayment>> GetPayment(int id)
            => Ok(await _payment.GetPayment(id));


        // PUT: api/Payment
        [HttpPut("")]
        public async Task<IActionResult> PutPayment( PutPayment payment)
        {
            await _payment.PutPayment(payment);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<Payment>> PostPayment(PostPayment payment)
        {
            await _payment.PostPayment(payment);
            return CreatedAtAction("GetPayment", payment);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePayment(int id)
        {
            await _payment.DeletePayment(id);
            return Ok();
        }
    }
}
