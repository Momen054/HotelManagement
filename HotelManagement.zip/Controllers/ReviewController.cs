﻿using HotelManagement.Data;
using HotelManagement.DTOs.Review;
using HotelManagement.Models;
using HotelManagement.serviceInterfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly IReview _review;
        public ReviewController(IReview review)
        {
            _review = review;
        }

        // GET: api/Review
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetReview>>> GetReview()
            => Ok(await _review.GetReview());


        // GET: api/Review/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GetReview>> GetReview(int id)
            => Ok(await _review.GetReview(id));


        // PUT: api/Review/5
        [HttpPut("")]
        public async Task<IActionResult> PutReview(PutReview review)
        {
            await _review.PutReview(review);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<Review>> PostReview(PostReview review)
        {
            await _review.PostReview(review);
            return CreatedAtAction("GetReview", review);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteReview(int id)
        {
            await _review.DeleteReview(id);
            return Ok();
        }
    }
}
