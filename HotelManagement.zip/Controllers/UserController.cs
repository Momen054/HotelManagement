﻿using HotelManagement.DTOs.User;
using HotelManagement.serviceInterfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUser _User;
        public UserController(IUser User)
        {
            _User = User;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetUser>>> GetUser()
            => Ok(await _User.GetAll());

        // GET: api/User/5
        [HttpGet("{Id}")]
        public async Task<ActionResult<GetUser>> GetUser(string Id)
            => Ok(await _User.GetUser(Id));


        [HttpDelete("")]
        public async Task<IActionResult> DeleteUser(string id)
        {
            await _User.DeleteUser(id);
            return Ok();
        }
    }
}
