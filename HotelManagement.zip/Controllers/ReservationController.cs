﻿using HotelManagement.Data;
using HotelManagement.DTOs.Reservation;
using HotelManagement.Models;
using HotelManagement.serviceInterfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private readonly IReservation _reservation;
        public ReservationController(IReservation reservation)
        {
            _reservation = reservation;
        }

        // GET: api/Reservation
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetReservation>>> GetReservation()
            => Ok(await _reservation.GetReservation());


        // GET: api/Reservation/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GetReservation>> GetReservation(int id)
            => Ok(await _reservation.GetReservation(id));


        // PUT: api/Reservation
        [HttpPut("")]
        public async Task<IActionResult> PutReservation(PutReservation reservation)
        {
            await _reservation.PutReservation(reservation);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<Reservation>> PostReservation(PostReservation reservation)
        {
            await _reservation.PostReservation(reservation);
            return CreatedAtAction("GetReservation", reservation);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteReservation(int id)
        {
            await _reservation.DeleteReservation(id);
            return Ok();
        }
    }
}
