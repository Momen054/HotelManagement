﻿using HotelManagement.Data;
using HotelManagement.DTOs.Invoice;
using HotelManagement.Models;
using HotelManagement.serviceInterfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly I_Invoice _invoice;
        public InvoiceController(I_Invoice invoice)
        {
            _invoice = invoice;
        }

        // GET: api/Invoice
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetInvoice>>> GetInvoice()
            => Ok(await _invoice.GetInvoice());


        // GET: api/Invoice/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GetInvoice>> GetInvoice(int id)
            => Ok(await _invoice.GetInvoice(id));


        // PUT: api/Invoice
        [HttpPut("")]
        public async Task<IActionResult> PutInvoice(PutInvoice invoice)
        {
            await _invoice.PutInvoice(invoice);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<Invoice>> PostInvoice(PostInvoice invoice)
        {
            await _invoice.PostInvoice(invoice);
            return CreatedAtAction("GetInvoice", invoice);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInvoice(int id)
        {
            await _invoice.DeleteInvoice(id);
            return Ok();
        }

    }
}
