﻿using HotelManagement.Data;
using HotelManagement.DTOs.RoomType;
using HotelManagement.Models;
using HotelManagement.serviceInterfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomTypeController : ControllerBase
    {
        private readonly IRoomType _roomType;
        public RoomTypeController(IRoomType roomType)
        {
            _roomType = roomType;
        }

        // GET: api/RoomType
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetRoomType>>> GetRoomType()
            => Ok(await _roomType.GetRoomType());


        // GET: api/RoomType/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GetRoomType>> GetRoomType(int id)
            => Ok(await _roomType.GetRoomType(id));


        // PUT: api/RoomType
        [HttpPut("")]
        public async Task<IActionResult> PutRoomType(PutRoomType roomType)
        {
            await _roomType.PutRoomType(roomType);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<RoomType>> PostRoomType(PostRoomType roomType)
        {
            await _roomType.PostRoomType(roomType);
            return CreatedAtAction("GetRoomType", roomType);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRoomType(int id)
        {
            await _roomType.DeleteRoomType(id);
            return Ok();
        }
    }
}
