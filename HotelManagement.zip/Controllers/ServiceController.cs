﻿using HotelManagement.Data;
using HotelManagement.DTOs.Service;
using HotelManagement.Models;
using HotelManagement.serviceInterfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceController : ControllerBase
    {
        private readonly IService _service;
        public ServiceController(IService service)
        {
            _service = service;
        }

        // GET: api/Service
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetService>>> GetService()
            => Ok(await _service.GetService());


        // GET: api/Service/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GetService>> GetService(int id)
            => Ok(await _service.GetService(id));


        // PUT: api/Service
        [HttpPut("")]
        public async Task<IActionResult> PutService(PutService service)
        {
            await _service.PutService(service);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<Service>> PostService(PostService service)
        {
            await _service.PostService(service);
            return CreatedAtAction("GetService", service);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteService(int id)
        {
            await _service.DeleteService(id);
            return Ok();
        }
    }
}
