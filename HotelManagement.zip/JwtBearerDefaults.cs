﻿internal class JwtBearerDefaults
{
}